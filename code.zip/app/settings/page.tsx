"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function SettingsPage() {
  const [apiKey, setApiKey] = useState("")
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    // Load API key from localStorage on mount
    const stored = localStorage.getItem("GEMINI_API_KEY")
    if (stored) {
      setApiKey(stored)
    }
  }, [])

  const handleSave = () => {
    if (apiKey.trim()) {
      localStorage.setItem("GEMINI_API_KEY", apiKey)
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background p-4">
      <div className="mx-auto w-full max-w-md">
        <Link href="/chat" className="mb-6 inline-block text-sm text-primary hover:underline">
          ← Back to Chat
        </Link>

        <Card className="p-6">
          <h1 className="mb-6 text-2xl font-semibold text-foreground">API Configuration</h1>

          <div className="space-y-4">
            <div>
              <label className="mb-2 block text-sm font-medium text-foreground">Gemini API Key</label>
              <Input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Enter your Gemini API key..."
                className="mb-4"
              />
              <p className="mb-4 text-xs text-muted-foreground">
                Your API key is stored locally in your browser and never sent to our servers.
              </p>
              <Button onClick={handleSave} className="w-full">
                {saved ? "Saved!" : "Save API Key"}
              </Button>
            </div>

            <div className="border-t border-border pt-4">
              <p className="text-sm text-muted-foreground">
                Don't have an API key? Get one from{" "}
                <a
                  href="https://ai.google.dev/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  Google AI Studio
                </a>
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
