"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function HomePage() {
  const [isHovering, setIsHovering] = useState(false)

  return (
    <div className="min-h-screen bg-white">
      <div className="fixed bottom-8 right-8">
        <div onMouseEnter={() => setIsHovering(true)} onMouseLeave={() => setIsHovering(false)} className="relative">
          <Link href="/chat">
            <Button
              className={`transition-all duration-300 ${
                isHovering ? "opacity-100 scale-100" : "opacity-0 scale-95 pointer-events-none"
              }`}
            >
              Chat
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
