"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"

const SendIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
  </svg>
)

const ImageIcon = () => (
  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
    />
  </svg>
)

const SparklesIcon = () => (
  <svg className="h-full w-full" fill="currentColor" viewBox="0 0 24 24">
    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
  </svg>
)

interface Message {
  role: "user" | "assistant"
  content: string
  image?: string
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [showSettings, setShowSettings] = useState(false)
  const [apiKey, setApiKey] = useState("")
  const [tempApiKey, setTempApiKey] = useState("")
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    // Load API key from localStorage on mount
    const savedKey = localStorage.getItem("GEMINI_API_KEY")
    if (savedKey) {
      setApiKey(savedKey)
    }
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const base64 = event.target?.result as string
        setSelectedImage(base64)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if ((!input.trim() && !selectedImage) || isLoading) return

    if (!apiKey) {
      setMessages((prev) => [...prev, { role: "assistant", content: "Please set your API key in settings first." }])
      return
    }

    const userMessage = input.trim() || ""
    setInput("")
    setMessages((prev) => [...prev, { role: "user", content: userMessage, image: selectedImage || undefined }])
    setSelectedImage(null)
    setIsLoading(true)

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage, apiKey, image: selectedImage }),
      })

      const data = await response.json()

      if (!response.ok) {
        console.error("[v0] API error response:", { status: response.status, data })
        throw new Error(data.error || "Failed to get response")
      }

      setMessages((prev) => [...prev, { role: "assistant", content: data.response }])
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred"
      console.error("[v0] Error sending message:", errorMessage)
      setMessages((prev) => [...prev, { role: "assistant", content: `Sorry, I encountered an error: ${errorMessage}` }])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSaveSettings = () => {
    if (tempApiKey.trim()) {
      localStorage.setItem("GEMINI_API_KEY", tempApiKey)
      setApiKey(tempApiKey)
      setShowSettings(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <SparklesIcon />
            </div>
            <h1 className="text-xl font-semibold text-foreground">Gemini Chat</h1>
          </div>
          <button
            onClick={() => {
              setTempApiKey(apiKey)
              setShowSettings(true)
            }}
            className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-primary/10 transition-colors"
          >
            Settings
          </button>
        </div>
      </header>

      {/* Chat Messages */}
      <main className="container mx-auto flex-1 overflow-y-auto px-4 py-6">
        <div className="mx-auto max-w-3xl space-y-6">
          {messages.length === 0 ? (
            <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <div className="h-8 w-8 text-primary">
                  <SparklesIcon />
                </div>
              </div>
              <h2 className="mb-2 text-2xl font-semibold text-foreground">Start a conversation</h2>
              <p className="text-muted-foreground">
                Ask me anything and I'll help you with information, ideas, and more.
              </p>
            </div>
          ) : (
            messages.map((message, index) => (
              <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                <Card
                  className={`max-w-[80%] px-4 py-3 ${
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-card text-card-foreground"
                  }`}
                >
                  {message.image && (
                    <img
                      src={message.image || "/placeholder.svg"}
                      alt="User uploaded"
                      className="max-w-sm rounded-md mb-2"
                    />
                  )}
                  <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</p>
                </Card>
              </div>
            ))
          )}
          {isLoading && (
            <div className="flex justify-start">
              <Card className="max-w-[80%] bg-card px-4 py-3">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 animate-bounce rounded-full bg-foreground [animation-delay:-0.3s]"></div>
                  <div className="h-2 w-2 animate-bounce rounded-full bg-foreground [animation-delay:-0.15s]"></div>
                  <div className="h-2 w-2 animate-bounce rounded-full bg-foreground"></div>
                </div>
              </Card>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Form */}
      <footer className="border-t border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="mx-auto max-w-3xl">
            {selectedImage && (
              <div className="mb-3 relative inline-block">
                <img
                  src={selectedImage || "/placeholder.svg"}
                  alt="Selected"
                  className="max-h-32 rounded-md border border-border"
                />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm hover:bg-destructive/90"
                >
                  ×
                </button>
              </div>
            )}
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                disabled={isLoading}
                className="flex-1"
              />
              <input ref={imageInputRef} type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
              <Button
                type="button"
                size="icon"
                onClick={() => imageInputRef.current?.click()}
                disabled={isLoading}
                title="Upload image"
              >
                <ImageIcon />
              </Button>
              <Button type="submit" disabled={isLoading || (!input.trim() && !selectedImage)} size="icon">
                <SendIcon />
              </Button>
            </form>
          </div>
        </div>
      </footer>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <Card className="w-full max-w-md mx-4 bg-card p-6">
            <h2 className="mb-4 text-lg font-semibold text-foreground">API Settings</h2>
            <div className="mb-4 space-y-2">
              <label className="block text-sm font-medium text-foreground">Gemini API Key</label>
              <Input
                type="password"
                value={tempApiKey}
                onChange={(e) => setTempApiKey(e.target.value)}
                placeholder="Enter your Gemini API key"
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">
                Your API key is stored locally in your browser and never sent to our servers.
              </p>
            </div>
            <div className="flex gap-2 justify-end">
              <Button
                onClick={() => setShowSettings(false)}
                className="bg-muted text-muted-foreground hover:bg-muted/80"
              >
                Cancel
              </Button>
              <Button onClick={handleSaveSettings} className="bg-primary hover:bg-primary/90">
                Save
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
