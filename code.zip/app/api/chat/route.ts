export async function POST(request: Request) {
  try {
    const { message, apiKey, image } = await request.json()

    if (!apiKey || (!message && !image)) {
      return Response.json({ error: "Missing API key or message/image" }, { status: 400 })
    }

    const parts: { text?: string; inlineData?: { mimeType: string; data: string } }[] = []

    if (image) {
      // Extract base64 data from data URL
      const base64Data = image.split(",")[1]
      const mimeType = image.match(/data:([^;]+)/)?.[1] || "image/jpeg"
      parts.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      })
    }

    if (message) {
      parts.push({ text: message })
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts,
            },
          ],
        }),
      },
    )

    const text = await response.text()

    if (!response.ok) {
      console.error("[v0] Gemini API error:", { status: response.status, body: text })
      return Response.json({ error: `API error: ${text}` }, { status: response.status })
    }

    const data = JSON.parse(text)
    const assistantMessage = data.candidates?.[0]?.content?.parts?.[0]?.text || "No response generated"

    return Response.json({ response: assistantMessage })
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error"
    console.error("[v0] Chat API error:", errorMessage)
    return Response.json({ error: errorMessage }, { status: 500 })
  }
}
